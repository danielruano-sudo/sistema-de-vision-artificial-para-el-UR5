from controller import Robot
import asyncio
import websockets
import json
import base64
import threading
import numpy as np
import cv2
import math

TIME_STEP = 32

MOTOR_NAMES = [
    "shoulder_pan_joint",
    "shoulder_lift_joint",
    "elbow_joint",
    "wrist_1_joint",
    "wrist_2_joint",
    "wrist_3_joint",
]

GRIPPER_MOTORS = [
    "ROBOTIQ 2F-140 Gripper::left finger joint",
    "ROBOTIQ 2F-140 Gripper::right finger joint",
]

# ── Posiciones base ────────────────────────────────────
HOME_POSITION    = [0.0,   -1.5708, 0.0,  -1.5708, 0.0, 0.0]
OBSERVE_POSITION = [1.508, -0.377,  0.0,  -1.571,  0.0, 1.382]
DROP_POSITION    = [-1.5,  -0.8,    0.6,  -1.571,  0.0, 0.0]

GRIPPER_OPEN  = 0.0
GRIPPER_CLOSE = 0.6
MOTOR_SPEED   = 3.0   # velocidad máxima
GRIPPER_SPEED = 2.0

# ── Parámetros cámara ──────────────────────────────────
# translation 0.266 0.869 0.759 (posición cámara en mundo)
# rotation -0.0342 -0.999 -0.0329 1.57 (apunta hacia abajo)
CAM_WIDTH  = 320
CAM_HEIGHT = 240
CAM_FOV    = 0.84
CAM_FX     = (CAM_WIDTH  / 2.0) / math.tan(CAM_FOV / 2.0)
CAM_FY     = CAM_FX
CAM_CX     = CAM_WIDTH  / 2.0
CAM_CY     = CAM_HEIGHT / 2.0

# Altura de la cámara sobre la superficie de la mesa
# camera y=0.869, mesa y~=0.85 → cámara ~0.02m sobre la mesa
# pero la cámara está en la muñeca, no fija — usamos altura dinámica
# La mesa está en y≈0.75 (superficie), los objetos en y≈0.87
# La cámara en OBSERVE está a ~0.35m sobre los objetos
CAM_Z_OVER_OBJECTS = 0.35  # metros sobre la superficie de los objetos

# Parámetros UR5e DH
UR5E_D1 = 0.1625
UR5E_A2 = 0.425
UR5E_A3 = 0.3922
UR5E_D4 = 0.1333
UR5E_D5 = 0.0997
UR5E_D6 = 0.0996

# Posición de la base del robot en el mundo (leer del nodo UR5e)
ROBOT_BASE = np.array([0.0, 0.0, 0.0])  # ajustar si el robot no está en origen

# ── Rangos HSV ─────────────────────────────────────────
BLUE_HSV_LOW  = np.array([105, 130, 60])
BLUE_HSV_HIGH = np.array([125, 255, 255])
RED_HSV_LOW1  = np.array([0,   130, 60])
RED_HSV_HIGH1 = np.array([8,   255, 255])
RED_HSV_LOW2  = np.array([165, 130, 60])
RED_HSV_HIGH2 = np.array([180, 255, 255])
MIN_AREA = 800

robot_state = {
    "status": "idle",
    "camera_frame_b64": "",
    "detections": {},
}
command_queue = []
frame_lock  = threading.Lock()
command_lock = threading.Lock()


# ── Visión ─────────────────────────────────────────────
def detect_objects(frame_bgr):
    h, w = frame_bgr.shape[:2]
    roi = frame_bgr[:int(h * 0.70), :]
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    detections = {}
    kernel = np.ones((7, 7), np.uint8)

    # Azul
    mask = cv2.inRange(hsv, BLUE_HSV_LOW, BLUE_HSV_HIGH)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if cnts:
        c = max(cnts, key=cv2.contourArea)
        if cv2.contourArea(c) > MIN_AREA:
            M = cv2.moments(c)
            if M["m00"] > 0:
                detections["blue"] = {
                    "x": int(M["m10"]/M["m00"]),
                    "y": int(M["m01"]/M["m00"]),
                    "area": int(cv2.contourArea(c))
                }

    # Rojo
    mask = cv2.bitwise_or(
        cv2.inRange(hsv, RED_HSV_LOW1, RED_HSV_HIGH1),
        cv2.inRange(hsv, RED_HSV_LOW2, RED_HSV_HIGH2)
    )
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if cnts:
        c = max(cnts, key=cv2.contourArea)
        if cv2.contourArea(c) > MIN_AREA:
            M = cv2.moments(c)
            if M["m00"] > 0:
                detections["red"] = {
                    "x": int(M["m10"]/M["m00"]),
                    "y": int(M["m01"]/M["m00"]),
                    "area": int(cv2.contourArea(c))
                }
    return detections


def draw_detections(frame_bgr, detections):
    vis = frame_bgr.copy()
    for color, label, col in [("blue","AZUL",(255,200,0)), ("red","ROJO",(60,60,255))]:
        if color in detections:
            d = detections[color]
            cv2.circle(vis, (d["x"], d["y"]), 22, col, 2)
            cv2.putText(vis, label, (d["x"]-20, d["y"]-28),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 2)
    return vis


# ── Proyección píxel → mundo ───────────────────────────
def pixel_to_world(px, py, cam_pos_world, cam_height_over_table):
    """
    Convierte un punto en píxeles a coordenadas 3D en el mundo.
    Asume que la cámara apunta hacia abajo (eje Y negativo en Webots).
    
    cam_pos_world: [x, y, z] posición actual de la cámara en el mundo
    cam_height_over_table: altura de la cámara sobre la mesa en metros
    """
    # Vector rayo desde el centro óptico
    ray_x = (px - CAM_CX) / CAM_FX
    ray_z = (py - CAM_CY) / CAM_FY  # en Webots Z es profundidad

    # Escalar al plano de la mesa
    # La cámara apunta hacia -Y, la intersección con la mesa es a cam_height metros
    world_x = cam_pos_world[0] + ray_x * cam_height_over_table
    world_z = cam_pos_world[2] + ray_z * cam_height_over_table
    world_y = cam_pos_world[1] - cam_height_over_table  # altura de la mesa

    return np.array([world_x, world_y, world_z])


def get_camera_world_pos(motors):
    """
    Estima la posición aproximada de la cámara en el mundo
    basándose en la posición de los joints actuales.
    Usamos la posición de OBSERVE como referencia calibrada.
    """
    # Cuando el robot está en OBSERVE la cámara está en ~(0.266, 0.869, 0.759)
    # Ajustamos según el pan actual
    pan = motors[0].getTargetPosition()
    obs_pan = OBSERVE_POSITION[0]
    delta_pan = pan - obs_pan

    # La cámara orbita alrededor de la base del robot
    cam_ref = np.array([0.266, 0.869, 0.759])
    radius = math.sqrt(cam_ref[0]**2 + cam_ref[2]**2)

    # Ángulo actual
    ref_angle = math.atan2(cam_ref[0], cam_ref[2])
    cur_angle = ref_angle + delta_pan

    cam_x = radius * math.sin(cur_angle)
    cam_z = radius * math.cos(cur_angle)
    cam_y = cam_ref[1]

    return np.array([cam_x, cam_y, cam_z])


# ── Cinemática Inversa UR5e ────────────────────────────
def ik_ur5e(tx, ty, tz):
    """
    IK para UR5e con gripper apuntando hacia abajo.
    tx, ty, tz: posición del efector final en coordenadas del mundo.
    Retorna [pan, lift, elbow, w1, w2, w3] o None si no alcanza.
    """
    # Vector desde la base al objetivo
    dx = tx - ROBOT_BASE[0]
    dy = ty - ROBOT_BASE[1]
    dz = tz - ROBOT_BASE[2]

    # Pan: ángulo en el plano horizontal
    pan = math.atan2(dx, dz)

    # Distancia horizontal
    r = math.sqrt(dx**2 + dz**2)

    # Altura relativa al joint 1 (descontar d1 y longitud gripper)
    h = dy - UR5E_D1 - UR5E_D6

    # IK planar (joints 2 y 3)
    reach = math.sqrt(r**2 + h**2)
    max_reach = UR5E_A2 + UR5E_A3

    if reach > max_reach * 0.98:
        print(f"[IK] ⚠ Objetivo fuera de alcance: {reach:.3f}m > {max_reach:.3f}m")
        reach = max_reach * 0.95

    cos_elbow = (r**2 + h**2 - UR5E_A2**2 - UR5E_A3**2) / (2 * UR5E_A2 * UR5E_A3)
    cos_elbow = max(-1.0, min(1.0, cos_elbow))
    elbow = math.acos(cos_elbow)  # codo arriba

    alpha = math.atan2(h, r)
    beta  = math.acos(max(-1.0, min(1.0,
            (r**2 + h**2 + UR5E_A2**2 - UR5E_A3**2) / (2 * UR5E_A2 * reach))))

    lift = -(alpha + beta)

    # Wrist para mantener gripper vertical (apuntando hacia abajo)
    w1 = math.pi/2 + lift + elbow

    joints = [
        round(pan,   4),
        round(lift,  4),
        round(elbow, 4),
        round(-w1,   4),
        round(-math.pi/2, 4),
        round(0.0,   4),
    ]
    print(f"[IK] target=({tx:.3f},{ty:.3f},{tz:.3f}) → joints={joints}")
    return joints


# ── Movimiento ─────────────────────────────────────────
def wait_steps(n):
    for _ in range(n):
        robot.step(TIME_STEP)

def move_to_position(motors, target, steps=30):
    current = [m.getTargetPosition() for m in motors]
    for s in range(steps):
        t = (s+1)/steps
        t = t*t*(3-2*t)
        for i, m in enumerate(motors):
            m.setPosition(current[i] + (target[i]-current[i])*t)
        robot.step(TIME_STEP)
    wait_steps(15)

def set_gripper(gm, pos):
    for m in gm:
        m.setPosition(pos)
    wait_steps(25)


def execute_pick(motors, gripper_motors, color):
    print(f"\n[Pick] ══ Iniciando pick de {color} ══")

    # 1. Ir a OBSERVE
    print(f"[Pick] 1. Moviendo a OBSERVE...")
    move_to_position(motors, OBSERVE_POSITION, steps=30)
    wait_steps(40)

    # 2. Centrar objeto rotando pan hasta que esté cerca del centro
    print(f"[Pick] 2. Centrando {color} en cámara...")
    centered = False
    for attempt in range(15):
        with frame_lock:
            dets = robot_state["detections"].copy()

        if color not in dets:
            print(f"[Pick]    No visible, intento {attempt+1}/15")
            wait_steps(15)
            continue

        px = dets[color]["x"]
        py = dets[color]["y"]
        error_x = px - CAM_CX
        error_y = py - CAM_CY
        print(f"[Pick]    Píxeles=({px},{py}) error=({error_x:.0f},{error_y:.0f})")

        if abs(error_x) < 20 and abs(error_y) < 20:
            print(f"[Pick]    ✓ Objeto centrado")
            centered = True
            break

        # Corregir pan proporcionalmente (ganancia baja para no oscilar)
        pan_correction = (error_x / CAM_CX) * 0.15
        new_pan = motors[0].getTargetPosition() - pan_correction
        motors[0].setPosition(new_pan)

        # Corregir lift para centrar en Y
        lift_correction = (error_y / CAM_CY) * 0.05
        new_lift = motors[1].getTargetPosition() + lift_correction
        motors[1].setPosition(new_lift)

        wait_steps(20)

    if not centered:
        # Si no centró perfectamente, usar última detección de todos modos
        with frame_lock:
            dets = robot_state["detections"].copy()
        if color not in dets:
            print(f"[Pick] ✗ {color} no detectado. Abortando.")
            return False
        print(f"[Pick]    Usando mejor detección disponible")

    # 3. Con objeto centrado, leer posición actual de la cámara
    wait_steps(20)
    with frame_lock:
        dets = robot_state["detections"].copy()

    if color not in dets:
        print(f"[Pick] ✗ Objeto perdido. Abortando.")
        return False

    detection = dets[color]
    print(f"[Pick] 3. Objeto en píxeles ({detection['x']}, {detection['y']})")

    # 4. Proyectar a coordenadas mundo desde posición actual de cámara
    cam_pos = get_camera_world_pos(motors)
    print(f"[Pick] 4. Cámara en mundo: {cam_pos.round(3)}")

    obj_world = pixel_to_world(
        detection["x"], detection["y"],
        cam_pos, CAM_Z_OVER_OBJECTS
    )
    print(f"[Pick]    Objeto en mundo: {obj_world.round(3)}")

    # 5. IK
    pre_target = obj_world.copy()
    pre_target[1] += 0.15
    pre_joints   = ik_ur5e(pre_target[0],  pre_target[1],  pre_target[2])
    grasp_joints = ik_ur5e(obj_world[0],   obj_world[1],   obj_world[2])

    # 6. Ejecutar
    print(f"[Pick] 5. Abriendo gripper...")
    set_gripper(gripper_motors, GRIPPER_OPEN)

    print(f"[Pick] 6. Pre-agarre...")
    move_to_position(motors, pre_joints, steps=30)

    print(f"[Pick] 7. Descendiendo...")
    move_to_position(motors, grasp_joints, steps=20)

    print(f"[Pick] 8. Cerrando gripper...")
    set_gripper(gripper_motors, GRIPPER_CLOSE)

    print(f"[Pick] 9. Levantando...")
    move_to_position(motors, pre_joints, steps=20)

    print(f"[Pick] ✓ Completado\n")
    return True

def execute_place(motors, gripper_motors):
    print("[Place] Depositando objeto...")
    move_to_position(motors, DROP_POSITION, steps=30)
    set_gripper(gripper_motors, GRIPPER_OPEN)
    move_to_position(motors, HOME_POSITION, steps=30)
    print("[Place] ✓ Depositado")


def process_action(action, motors, gripper_motors):
    robot_state["status"] = "moving"
    print(f"[Robot] ▶ {action}")

    if action == "pick_blue":
        execute_pick(motors, gripper_motors, "blue")
    elif action == "pick_red":
        execute_pick(motors, gripper_motors, "red")
    elif action == "place":
        execute_place(motors, gripper_motors)
    elif action == "observe":
        move_to_position(motors, OBSERVE_POSITION, steps=30)
    elif action == "home":
        set_gripper(gripper_motors, GRIPPER_OPEN)
        move_to_position(motors, HOME_POSITION, steps=30)

    robot_state["status"] = "idle"
    print(f"[Robot] ✓ {action} listo")


def interpret_command(text, detections):
    t = text.lower().strip()
    if any(w in t for w in ["suelt","deja","depos","soltar","libera","drop"]):
        return "place", "Depositando objeto."
    if any(w in t for w in ["inicio","home","inicial","reset","vuelve","regresa"]):
        return "home", "Volviendo a inicio."
    if any(w in t for w in ["observ","mira","ves","ver","muestra","dime","hay","escan"]):
        obs = []
        if "blue" in detections: obs.append("cilindro azul")
        if "red"  in detections: obs.append("cubo rojo")
        return "observe", ("Veo: " + " y ".join(obs)) if obs else "No detecto objetos."
    if any(w in t for w in ["azul","blue","cilindr"]):
        return "pick_blue", "Buscando y tomando el cilindro azul."
    if any(w in t for w in ["rojo","red","cubo","cub","caja"]):
        return "pick_red", "Buscando y tomando el cubo rojo."
    if any(w in t for w in ["toma","agarra","coge","pick","recoge","lleva"]):
        if "blue" in detections: return "pick_blue", "Tomando el cilindro azul."
        if "red"  in detections: return "pick_red",  "Tomando el cubo rojo."
        return "observe", "Observando primero."
    return "observe", "Observando la escena."


# ── WebSocket ──────────────────────────────────────────
async def handle_client(websocket):
    print("[WS] Cliente conectado")
    try:
        async for message in websocket:
            data = json.loads(message)
            if data.get("type") == "command":
                text = data.get("text", "")
                with frame_lock:
                    dets = robot_state["detections"].copy()
                action, msg = interpret_command(text, dets)
                print(f"[Cmd] '{text}' → {action}")
                await websocket.send(json.dumps({
                    "type": "decision", "action": action,
                    "message": msg, "detections": dets
                }))
                with command_lock:
                    if robot_state["status"] == "idle":
                        command_queue.append(action)
                    else:
                        print("[Robot] Ocupado")
            elif data.get("type") == "request_frame":
                with frame_lock:
                    frame  = robot_state["camera_frame_b64"]
                    dets   = robot_state["detections"].copy()
                    status = robot_state["status"]
                await websocket.send(json.dumps({
                    "type": "frame", "data": frame,
                    "detections": dets, "status": status
                }))
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        print("[WS] Cliente desconectado")


def start_websocket_server():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    async def main():
        async with websockets.serve(handle_client, "localhost", 8765):
            print("[WS] ws://localhost:8765")
            await asyncio.Future()
    loop.run_until_complete(main())


# ── Cámara ─────────────────────────────────────────────
def webots_frame_to_bgr(camera):
    w = camera.getWidth(); h = camera.getHeight()
    raw = camera.getImage()
    arr = np.frombuffer(raw, dtype=np.uint8).reshape((h, w, 4))
    return cv2.cvtColor(arr, cv2.COLOR_BGRA2BGR)

def frame_to_base64_jpeg(frame_bgr):
    _, buf = cv2.imencode(".jpg", frame_bgr, [cv2.IMWRITE_JPEG_QUALITY, 80])
    return base64.b64encode(buf).decode("utf-8")


# ── Inicialización ─────────────────────────────────────
robot        = Robot()
motors       = [robot.getDevice(n) for n in MOTOR_NAMES]
gripper_mots = [robot.getDevice(n) for n in GRIPPER_MOTORS]
camera       = robot.getDevice("wrist_camera")

for m in motors:
    m.setPosition(float('inf'))
    m.setVelocity(MOTOR_SPEED)
    ps = m.getPositionSensor()
    if ps: ps.enable(TIME_STEP)

for m in gripper_mots:
    m.setPosition(GRIPPER_OPEN)
    m.setVelocity(GRIPPER_SPEED)

camera.enable(TIME_STEP)

for i, m in enumerate(motors):
    m.setPosition(OBSERVE_POSITION[i])

ws_thread = threading.Thread(target=start_websocket_server, daemon=True)
ws_thread.start()

frame_counter = 0
print("[UR5] Listo — visión dinámica activa")

# ── Bucle principal ────────────────────────────────────
while robot.step(TIME_STEP) != -1:
    frame_counter += 1

    if frame_counter % 8 == 0:
        try:
            bgr  = webots_frame_to_bgr(camera)
            dets = detect_objects(bgr)
            vis  = draw_detections(bgr, dets)
            b64  = frame_to_base64_jpeg(vis)
            with frame_lock:
                robot_state["camera_frame_b64"] = b64
                robot_state["detections"]       = dets
            if dets:
                print(f"[Vision] {list(dets.keys())}")
        except Exception as e:
            print(f"[Vision] Error: {e}")

    with command_lock:
        if command_queue and robot_state["status"] == "idle":
            action = command_queue.pop(0)
            threading.Thread(
                target=process_action,
                args=(action, motors, gripper_mots),
                daemon=True
            ).start()